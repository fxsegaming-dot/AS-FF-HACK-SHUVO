# FF Headshot Pro

A simple Android Studio project built with Kotlin and Jetpack Compose.

## Features
- Training mode selector: Drag Headshot, One Tap, Aim Practice
- Sensitivity slider (0–200)
- Fire button size slider (20–100%)
- Practice guide
- Dark themed interface

## Build
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

This is a training/settings helper only. It does not modify Free Fire or provide cheats, auto-aim, wallhacks, or player tracking.
