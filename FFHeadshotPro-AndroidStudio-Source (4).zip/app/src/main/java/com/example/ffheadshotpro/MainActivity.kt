package com.example.ffheadshotpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Dark = Color(0xFF10141C)
private val Panel = Color(0xFF1B2430)
private val Green = Color(0xFF32D583)
private val Muted = Color(0xFFABB7C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HeadshotApp() }
    }
}

@Composable
fun HeadshotApp() {
    var mode by remember { mutableStateOf("Drag Headshot") }
    var sensitivity by remember { mutableFloatStateOf(95f) }
    var fireSize by remember { mutableFloatStateOf(48f) }
    var showGuide by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            background = Dark,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Dark) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯", fontSize = 30.sp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("FF HEADSHOT PRO", fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text("TRAINING & SETTINGS TOOL", color = Muted, fontSize = 11.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("HEADSHOT PRACTICE", color = Green, fontWeight = FontWeight.Bold)
                        Text("নিজের aim অনুশীলন করুন", color = Muted)
                        Text("এটি একটি সহায়ক ক্যালকুলেটর—গেমের ভেতরে কোনো পরিবর্তন করে না।", color = Muted, fontSize = 12.sp)
                    }
                }

                Text("TRAINING MODE", color = Green, fontWeight = FontWeight.Bold)
                listOf("Drag Headshot", "One Tap", "Aim Practice").forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = mode == item, onClick = { mode = item })
                        Text(item)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Sensitivity", fontWeight = FontWeight.Bold)
                        Text(sensitivity.toInt().toString(), color = Green, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0f..200f)
                        Text("Fire Button Size", fontWeight = FontWeight.Bold)
                        Text("${fireSize.toInt()}%", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Slider(value = fireSize, onValueChange = { fireSize = it }, valueRange = 20f..100f)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("YOUR TRAINING SETTINGS", color = Green, fontWeight = FontWeight.Bold)
                        Text("Mode: $mode")
                        Text("Sensitivity: ${sensitivity.toInt()}")
                        Text("Fire Button: ${fireSize.toInt()}%")
                    }
                }

                Button(
                    onClick = { showGuide = !showGuide },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Dark)
                ) {
                    Text(if (showGuide) "Hide Practice Guide" else "Show Practice Guide", fontWeight = FontWeight.Bold)
                }

                if (showGuide) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PRACTICE GUIDE", color = Green, fontWeight = FontWeight.Bold)
                            Text("1. Training Ground-এ গিয়ে স্থির লক্ষ্যবস্তুতে aim করুন।")
                            Text("2. ছোট ও নিয়ন্ত্রিত drag অনুশীলন করুন।")
                            Text("3. Sensitivity অল্প অল্প করে বদলে নিজের জন্য আরামদায়ক মান খুঁজুন।")
                            Text("4. নিয়মিত বিরতি নিন এবং নিজের নিয়ন্ত্রণ বজায় রাখুন।")
                        }
                    }
                }

                Text(
                    "নোট: এই অ্যাপ কোনো hack, auto-aim, wallhack বা enemy location tracker নয়।",
                    color = Muted, fontSize = 11.sp
                )
                Text("FF Headshot Pro • Version 1.0", color = Muted, fontSize = 11.sp)
            }
        }
    }
}
